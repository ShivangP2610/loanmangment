<?php

namespace App\Http\Controllers;

use App\Models\Cam;
use App\Models\Credit;
use App\Models\Customer;
use App\Models\FormOffice; 
use Illuminate\Support\Facades\Storage;
use Illuminate\Http\Request;

class CamController extends Controller
{
    public function viewdocument()
    {
        $cams = Cam::orderBy('created_at', 'desc')->get();
        $data = compact('cams');
        return view('viewcam')->with($data);

    } 

    public function viewdocument1($id)
    {
        $cams = Cam::where('lon_id',$id)->get();
        $data = compact('cams');
        return view('viewcam')->with($data);
    }

    public function create()
    {
        $url = url('/cam/add');
        $title = 'CAM Uplod';
        $btext = "Submit";
        $data = compact('url', 'title', 'btext');
        $loans = FormOffice::where('app_status', 'document done')->get();
        $customers = Customer::all();
        // dd($customers)->count();
        return view('cam')->with(array_merge($data, ['loans' => $loans, 'customers' => $customers]));
    }  

   


    public function store(Request $request)
    {
        //  dd($request->all())
        $request->validate([
            'lon_id' => 'required',
            'customer_id' => 'required',
            'excel_uplod' => 'required|file|mimes:xlsx,xls'
        ]);
        $cam = new Cam();
        $cam->lon_id = $request->lon_id;
        $cam->customer_id = $request->customer_id;
        $file = $request->file('excel_uplod');

        $fileName = time() . '.' . $file->getClientOriginalExtension();
        $file->storeAs('public/documents/cam', $fileName);  
        $cam->excel_uplod = $fileName; 
        // dd($file); 
        $appstatus = 'cam approved';
        FormOffice::where('loan_id', $request->lon_id)->update(['app_status' => $appstatus]);
        // $FormOffice = FormOffice::find($request->lon_id);
        // $FormOffice->app_status = $request->status;
        // $FormOffice->update();

        $cam->save();
        return redirect()->back()->with('success', 'Document Submit successfully.');
    }    


    public function creditcreate (){
        $url = url('/credit/add');
        $title = 'Credit Uplod';
        $btext = "Submit";
        $data = compact('url', 'title', 'btext');

        $loans = FormOffice::where('app_status', 'cam approved')->get();
        $customers = Customer::all();
        // dd($customers)->count();
        return view('credit')->with(array_merge($data, ['loans' => $loans, 'customers' => $customers]));
    } 


    public function creditstore(Request $request)
    {
        //  dd($request->all());

        $request->validate([
            'lon_id' => 'required',
            'customer_id' => 'required',
            'cam_uplod' => 'required|file|mimes:xlsx,xls',
            'final_uplod' => 'required|file|mimes:xlsx,xls'
        ]);




        $cam = new Credit();
        $cam->lon_id = $request->lon_id;
        $cam->customer_id = $request->customer_id;
      
        $file = $request->file('cam_uplod');
        $fileName = time() . '.' . $file->getClientOriginalExtension();
        $file->storeAs('public/documents/credit', $fileName);  
        $cam->cam_uplod = $fileName;   

        $file = $request->file('final_uplod');
        $fileName = time() . '.' . $file->getClientOriginalExtension();
        $file->storeAs('public/documents/credit', $fileName);  
        $cam->final_uplod = $fileName; 

        // $FormOffice = FormOffice::find($request->lon_id);
        // $FormOffice->app_status = $request->status; 

       
        $appstatus = 'credit approved';
        FormOffice::where('loan_id', $request->lon_id)->update(['app_status' => $appstatus]);

        $cam->save();
        return redirect()->back()->with('success', 'Document Submit successfully.');
    }    

    public function show($id)    
    {
        // // $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xls();
    
        // $reader->setReadDataOnly(TRUE);
        // $uri = "public/storage/resultsheet/Revival Royal Academy_Primary 5B_1572753672.xlsx";
    
        // $spreadsheet = $reader->load($uri);
        // $worksheet = $spreadsheet->getActiveSheet();
    
        // return view('student.result', compact('worksheet'));
    }  


    public function creditview()
    {
        $creditview = Credit::orderBy('created_at', 'desc')->get();
        $data = compact('creditview');
        return view('viewcredit')->with($data);

    } 


    public function downloadCamuplod($id)
{
    // Retrieve document details from database
    $camuplod = Cam::findOrFail($id);
// dd($camuplod);
    // Construct the file path
    $filePath = 'public/documents/cam/' . $camuplod->excel_uplod; 
    // dd($filePath);

    // Check if salary slip file exists
    if (Storage::exists($filePath)) {
        return Storage::download($filePath);
    } else {
        abort(404);
    }
}   

 
public function redirectToView(Request $request)
{
    $lon_id = $request->input('lon_id');

    
}


}
